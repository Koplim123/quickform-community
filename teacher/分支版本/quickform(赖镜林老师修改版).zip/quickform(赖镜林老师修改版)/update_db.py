import os
import sys
import sqlite3

# 添加当前目录到系统路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def update_database():
    """
    更新数据库结构，添加缺失的列
    """
    print("开始更新数据库结构...")
    
    # 连接到SQLite数据库
    conn = sqlite3.connect('quickform.db')
    cursor = conn.cursor()
    
    try:
        # 1. 检查并添加user表的is_admin和is_active字段
        print("\n1. 检查user表结构...")
        
        # 获取user表的所有列
        cursor.execute("PRAGMA table_info(user)")
        user_columns = [column[1] for column in cursor.fetchall()]
        
        # 检查is_admin列
        if 'is_admin' not in user_columns:
            print("   添加is_admin列...")
            cursor.execute("ALTER TABLE user ADD COLUMN is_admin INTEGER DEFAULT 0")
        else:
            print("   is_admin列已存在")
        
        # 检查is_active列
        if 'is_active' not in user_columns:
            print("   添加is_active列...")
            cursor.execute("ALTER TABLE user ADD COLUMN is_active INTEGER DEFAULT 1")
        else:
            print("   is_active列已存在")
        
        # 2. 检查并创建system_config表
        print("\n2. 检查system_config表...")
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='system_config'")
        if not cursor.fetchone():
            print("   创建system_config表...")
            cursor.execute("""
                CREATE TABLE system_config (
                    id INTEGER PRIMARY KEY,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    description TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
        else:
            print("   system_config表已存在")
        
        # 提交更改
        conn.commit()
        print("\n数据库结构更新完成!")
        
    except Exception as e:
        print(f"\n更新失败: {str(e)}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == '__main__':
    update_database()