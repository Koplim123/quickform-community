import requests
import json

# 测试API的URL
BASE_URL = 'http://192.168.199.51:5001'
TASK_ID = '1620c6e6-58b7-4631-bd84-018b876173f9'  # 用户提供的任务ID

print("=== 测试开始 ===")

# 1. 获取所有提交记录
print("\n1. 获取所有提交记录...")
response = requests.get(f'{BASE_URL}/api/submit/{TASK_ID}')
if response.status_code == 200:
    data = response.json()
    print(f"   成功获取 {data['total_submissions']} 条记录")
    if data['total_submissions'] > 0:
        # 保存第一条记录的ID用于后续测试
        test_submission_id = data['submissions'][0]['id']
        print(f"   第一条记录ID: {test_submission_id}")
    else:
        print("   没有可测试的记录")
        exit()
else:
    print(f"   失败: {response.status_code} - {response.text}")
    exit()

# 2. 测试更新记录
print(f"\n2. 测试更新记录 {test_submission_id}...")
update_data = {
    'test_field': 'updated_value',
    'timestamp': '2023-12-05'
}
response = requests.put(
    f'{BASE_URL}/api/submit/{TASK_ID}/{test_submission_id}',
    json=update_data,
    headers={'Content-Type': 'application/json'}
)
if response.status_code == 200:
    print(f"   成功: {response.json()}")
else:
    print(f"   失败: {response.status_code} - {response.text}")

# 3. 验证更新是否成功
print("\n3. 验证更新是否成功...")
response = requests.get(f'{BASE_URL}/api/submit/{TASK_ID}')
if response.status_code == 200:
    data = response.json()
    for submission in data['submissions']:
        if submission['id'] == test_submission_id:
            print(f"   记录 {test_submission_id} 已更新: {json.dumps(submission['data'], ensure_ascii=False)}")
            break
else:
    print(f"   失败: {response.status_code} - {response.text}")

# 4. 测试删除记录
print(f"\n4. 测试删除记录 {test_submission_id}...")
response = requests.delete(f'{BASE_URL}/api/submit/{TASK_ID}/{test_submission_id}')
if response.status_code == 200:
    print(f"   成功: {response.json()}")
else:
    print(f"   失败: {response.status_code} - {response.text}")

# 5. 验证删除是否成功
print("\n5. 验证删除是否成功...")
response = requests.get(f'{BASE_URL}/api/submit/{TASK_ID}')
if response.status_code == 200:
    data = response.json()
    deleted = True
    for submission in data['submissions']:
        if submission['id'] == test_submission_id:
            deleted = False
            break
    if deleted:
        print(f"   记录 {test_submission_id} 已成功删除")
    else:
        print(f"   记录 {test_submission_id} 未被删除")
else:
    print(f"   失败: {response.status_code} - {response.text}")

print("\n=== 测试结束 ===")
