import os
import sys
import json
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 添加当前目录到系统路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 导入应用模块
from app import Base, User, SystemConfig, bcrypt

# 数据库配置
DATABASE_URL = 'sqlite:///quickform.db'
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_system():
    """
    初始化系统配置和管理员用户
    """
    print("开始初始化系统...")
    
    db = SessionLocal()
    try:
        # 1. 检查并创建系统配置
        print("\n1. 初始化系统配置...")
        
        # 检查是否已存在配置
        existing_config = db.query(SystemConfig).filter_by(key='allow_registration').first()
        if not existing_config:
            # 创建默认配置
            default_configs = [
                SystemConfig(
                    key='allow_registration',
                    value='1',  # 1: 允许注册, 0: 禁止注册
                    description='是否允许新用户注册'
                )
            ]
            
            for config in default_configs:
                db.add(config)
                print(f"   创建配置项: {config.key} = {config.value}")
        else:
            print("   系统配置已存在，跳过...")
        
        # 2. 检查并创建管理员用户
        print("\n2. 初始化管理员用户...")
        
        # 检查是否已存在管理员用户
        admin_user = db.query(User).filter_by(username='admin').first()
        if not admin_user:
            # 创建管理员用户
            hashed_password = bcrypt.generate_password_hash('admin123').decode('utf-8')
            admin_user = User(
                username='admin',
                email='admin@example.com',
                password=hashed_password,
                is_admin=1,  # 设置为管理员
                is_active=1  # 启用账号
            )
            
            db.add(admin_user)
            print("   创建管理员用户成功!")
            print("   用户名: admin")
            print("   密码: admin123")
            print("   请登录后及时修改密码!")
        else:
            print("   管理员用户已存在，跳过...")
            print(f"   用户名: {admin_user.username}")
        
        # 提交所有更改
        db.commit()
        print("\n系统初始化完成!")
        
    except Exception as e:
        print(f"\n初始化失败: {str(e)}")
        db.rollback()
    finally:
        db.close()

if __name__ == '__main__':
    init_system()